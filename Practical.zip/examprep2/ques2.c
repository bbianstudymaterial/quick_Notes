//Question2

/*WAP to display ACII value of a character*/
#include<stdio.h>
#include<conio.h>
void main()
{
    char ch;
    printf(" Enter your Character: ");
    scanf("%c",&ch);
    printf("\nThe ASCII of %c character is %d",ch,ch);
    puts("\nPress any key to continue.");
    getch();
}
