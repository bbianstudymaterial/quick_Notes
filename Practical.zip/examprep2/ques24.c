
#include <stdio.h>


void lower(int a[10][10], int r, int c)
{
	for (int i = 0; i < r; i++)
	{
		for (int j = 0; j < c; j++)
		{
			if (i > j)
				printf("0");
			else
				printf("%d", a[i][j]);
			printf(" ");
		}
		printf("\n");
	}
}

void upper(int a[10][10], int r, int c)
{
	for (int i = 0; i < r; i++)
	{
		for (int j = 0; j < c; j++)
		{
			if (i < j)
				printf("0");
			else
				printf("%d", a[i][j]);
			printf(" ");
		}
		printf("\n");
	}
}
int main()
{
	
	int r, c, a[10][10], i, j;
	printf("Enter the order of the matrix: ");
	scanf("%d %d", &r, &c);
	printf("\nEnter the matrix: \n");
	for (i = 0; i < r; i++)
		for (j = 0; j < c; j++)
			scanf("%d", &a[i][j]);

	printf("\nLower Triangular Matrix is :\n");
	lower(a, r, c);
	printf("\nUpper Triangular Matrix is :\n");
	upper(a, r, c);
	return 0;
}
