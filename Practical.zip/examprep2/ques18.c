//18
#include<stdio.h>
#include<conio.h>
void asc(int [],int);
int insert(int [],int,int);
void main()
{
    int n,i,a[20],ne;
    printf("\nEnter the number of terms(max 20):");
    scanf("%d",&n);
    printf("\nEnter the values:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    asc(a,n);
    printf("\nEnter the value to be inserted:");
    scanf("%d",&ne);
    n=insert(a,n,ne);
    for(i=0;i<n;i++)
    {
        printf(" %d ",a[i]);
    }
    getch();
}
void asc(int ar[],int n)
{
    int min,i,j,temp;
    for(i=0;i<n-1;i++)
    {
        min=i;
        for(j=i+1;j<n;j++)
        {
            if(ar[j]<ar[min])
                min=j;
        }
        if(i!=min)
        {
            temp=ar[i];
            ar[i]=ar[min];
            ar[min]=temp;
        }
    }
}
int insert(int a[],int n,int ne)
{
    if(n>=20)
    {
        printf("\nOVERFLOW!!\n3");
        return n;
    }
    for(int i=n-1;a[i]>=ne;i--)
    {
        a[i+1]=a[i];
        a[i]=ne;
    }
    return (n+1);
}
