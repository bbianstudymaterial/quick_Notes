#include <stdio.h>
#include <string.h>

int main() {
   char s[100];
   int i;
   printf("\nEnter a string : ");
   gets(s);

   for (i = 0; s[i]!='\0'; i++) {
      if(s[i] >= 'a' && s[i] <= 'z')//s[i] is betn 97-122
    {
         s[i] = s[i] - 32;//for upper case
    }
      else
        s[i] = s[i] + 32;//for lower case //s[i] is betn 65-90
   }
   printf("\nString after coverting : %s", s);
   return 0;
}
