//Question 1
#include<stdio.h>
#include<conio.h>
void main()
{
    int n=0;
    float f,c;
    printf("\n Temperature Conversion");
    printf("\n------------------------");
    printf("\n Enter 1 to select Farenheit.");
    printf("\n Enter 2 to select Centigrade.");
    printf("\n Choose Your Temperature Scale: ");
     scanf("%d",&n);
    printf("\n--------------------------------");
    if(n==1)
    {   
        printf("\n Convert Your Temperature farenheit to Centigrade");
        printf("-----------------------------------------------------");
        printf("\n Enter your temperature in Degree farenheit: ");
        scanf("%f",&f);
        c = 5.0/9.0 * (f-32);
        printf("\n Your Temperature in Degree Centigrade is: %6.2f",c);

    }
    else
    {
        if(n==2)
        {
            printf("\n Convert Your Temperature Centigrade to Farenheit");
            printf("-----------------------------------------------------");
            printf("\n Enter your temperature in Degree Centigrade: ");
            scanf("%f",&c);
            f = (9.0/5.0 * c) + 32;
            printf("\n Your Temperature in Degree Farenheit is %6.2f",f);
        }
        else{
            
                printf("\n-----Invalid! Option--------");
        
        }
    }
    getch();
}