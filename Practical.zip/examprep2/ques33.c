#include <stdio.h>
int x, y, *a, *b, temp;
void swap();

int main()
{
   extern int x, y, *a, *b, temp;

   printf("Enter the two values: ");
   scanf("%d%d", &x, &y);

   printf("Before Swapping\nx = %d\ny = %d\n", x, y);
   swap();

   printf("After Swapping\nx = %d\ny = %d\n", x, y);

   return 0;
}

void swap()
{
   extern int x, y, *a, *b, temp;
   a = &x;
   b = &y;

   temp = *b;
   *b = *a;
   *a = temp;
}
