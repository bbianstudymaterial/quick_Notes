//9

#include<stdio.h>
#include<conio.h>
void main()
{
    int n,max,a,min,sum;
    float avg;
    printf("Enter the no. of terms: ");
    scanf("%d",&n);
    printf("\nEnter the terms: ");
    scanf("%d",&a);
    max=a;
    min=a;
    sum=a;
    for(int i=1;i<n;i++)
    {
        scanf("%d",&a);
        if(a>max)
            max=a;
        if(a<min)
            min=a;
        sum+=a;
    }
    avg=sum/n;
    printf("\nThe maximum number is %d",max);
    printf("\nThe minimum number is %d",min);
    printf("\nThe sum number is %d",sum);
    printf("\nThe average number is %f",avg);
    getch();
}
