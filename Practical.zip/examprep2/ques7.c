//Question 7

#include<stdio.h>
#include<conio.h>
void main()
{
    int x,y,n;
    printf(" Enter the value of n: ");
    scanf("%d",&n);
    printf("\nEnter the value of x: ");
    scanf("%d",&x);
    switch(n)
    {
        case 1: y = n + x;
         break;
        case 2: y = 1 + x/n;
         break;
        case 3: y = n + 3*x;
         break;
        default: y = 1 + n*x;
        break;
    }
    printf("\n The value of y is %d",y);
    getch();
}