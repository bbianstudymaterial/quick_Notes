//17
#include<stdio.h>
#include<conio.h>
#include<math.h>
int fact(int);
void main()
{
    int n,x,i,p=1,q=1;
    float res=1.0;
    printf("\nEnter the no of terms:");
    scanf("%d",&n);
    printf("\nEnter the value of x:");
    scanf("%d",&x);
    for(i=1;i<n;i++)
    {
        p+=2;
        res+=(pow(x,q)/fact(q))-(pow(x,p)/fact(p));
        q+=2;
    }
    printf("\nThe sum of the series is %0.3f",res);
    getch();
}
int fact(int a)
{
    if(a==0||a==1)
        return 1;
    else
        return (a*fact(a-1));
}
