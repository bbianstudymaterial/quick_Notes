//Question 3

#include<stdio.h>
#include<conio.h>
void main()
{
    int i, num, rem, sum;
    printf("\n To check Perfect Number or not.");
    printf("\n---------------------------------");
    printf("\n Enter a number: ");
    scanf("%d",&num);
    for(i=1;i<num;i++)
    {
        rem = num % i;
        if(rem==0)
         sum = sum + i;
    }
    if(sum==num)
     printf("\n %d is the perfect number.",num);
    else
     printf("\n %d is not perfect number.",num);
   getch();
}