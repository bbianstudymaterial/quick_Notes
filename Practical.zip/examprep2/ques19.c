//19
#include<stdio.h>
#include<conio.h>
int fact(int);
int factR(int);
void main()
{
    int n;
    printf("\nEnter the number:");
    scanf("%d",&n);
    printf("\nThe factorial of %d using non-recursive procedure is %d",n,fact(n));
    printf("\nThe factorial of %d using recursive procedure is %d",n,factR(n));
    getch();
}
int fact(int a)
{
    if(a==0||a==1)
        return 1;
    else
    {
        for(int i=a-1;i>0;i--)
        {
            a*=i;
        }
        return a;
    }
}
int factR(int a)
{
    if(a==0||a==1)
        return 1;
    else
        return (a*fact(a-1));
}

