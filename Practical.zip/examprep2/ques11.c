#include <stdio.h>
#include <conio.h>
#include <math.h>
void main()
{
    float a, b, c, d, r1, r2, x1r, x1i, x2r, x2i;
    printf("\nEnter the coeficients a, b, c");
    scanf("%f %f %f",&a,&b,&c);
    d = b*b - 4*a*c;
    if(d>0)
    {
        printf("\nReal and unequal roots:");
        r1 = (-b + sqrt(d)) / (2*a);
        r2 = (-b - sqrt(d)) / (2*a);
        printf("\nThe Roots are: %6.2f and %6.2f",r1,r2);
    }
    else if(d==0){
            printf("\nReal and Equal Roots");
            r1 = (-b)/(2*a);
            printf("The Roots is %6.2f",r1);
    }
        
    else
   {
            printf("\nNo real roots, roots are complex");
            x1r = -b/(2*a);
            x1i = sqrt(fabs(d))/(2*a);
            x2r = x1r;
            x2i = -x1i;
            printf("\n The roots are %6.2f + %6.2fi and %6.2f + %6.2fi",x1r,x1i,x2r,x2i);
   }
    
    getch();
}
