#include <stdio.h>
#include <conio.h>
int n, count, t1, t2, t3;
int fibo(int a, int b);
int main()
{
    printf("\nHow many terms to be printed ? ");
    scanf("%d",&n);
    t1 = 0;
    t2 = 1;
    printf("\n The first %d terms in Fibonacci series are \n",n);
    printf("%5d %5d",t1,t2);
    count = 2;
    fibo(t1,t2);
    getch();
}
int fibo(int t1,int t2)
{
    if(count>=n)
     return (count);
    else
    {
        t3 = t1 + t2;
        printf("%5d",t3);
        count ++;
        t1 = t2;
        t2 = t3;
        fibo(t1,t2);
    }
}