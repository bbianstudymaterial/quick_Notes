//Question 4
#include<stdio.h>
#include<conio.h>
void main()
{
    int a, b, c, big;
    printf("\nEnter the first number: ");
    scanf("%d",&a);
    printf("\nEnter the second number: ");
    scanf("%d",&b);
    printf("\nEnter the third number: ");
    scanf("%d",&c);
    big = a;
    if(big<b)
    {
      big = b;
    }
    else 
    {
        if(big<c)
          big = c;
    }
    printf("\n---------------------------");
    printf("\n The biggest number is : %d",big);
   getch();
}