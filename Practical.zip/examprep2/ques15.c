//15
#include<stdio.h>
#include<conio.h>
void binary(float);
void main()
{
    float n;
    printf("Enter a number:\t");
    scanf("%f",&n);
    binary(n);
    getch;
}
void binary(float a)
{
    int i,j,k,n=a,b[20],c[20],result=0;
    float z=a-n;
    for(i=0;n!=0;i++)
    {
        b[i]=n%2;
        n=n/2;
    }
     printf("\nThe equivalent binary number is ");
    for(j=0,k=i-1;j<i;j++)
    {
        c[j]=b[k];
        printf("%d",c[j]);
        k--;
    }
    while(z!=0)
    {
  
        z=z*2;
        int x=z;
        result=result*10+x;
        z-=x;
    }
    printf("%d",result);
}
