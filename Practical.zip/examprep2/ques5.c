//5
//* logical operator: && ,|| ,!=
#include <stdio.h>
#include <conio.h>
void main()
{
    int age,var;
    char g,mar;
    printf("enter your gender... m for male and f for female:");
    scanf("%c",&g);

    printf("enter your age:");
    scanf("%d",&age);

    printf("r u married:");
    scanf("%*c%c",&mar);

    /*to read character values after skipping spaces, tabs we need to skip any value between two
    character values and this is possible by using skip format specifier "%*c"              */

    if (mar=='y')
        printf("u r selected !");
   else if(mar=='n' && g=='m' && age>30)
        printf("u r selected !");
   else if(mar=='n' && g=='f' && age>25)
        printf("u r selected !");
   else
    printf("u r not selected !");
   
   getch();
}
