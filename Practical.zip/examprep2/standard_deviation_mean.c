//Question 10
#include<stdio.h>
#include<conio.h>
#include<math.h>
void main()
{
    float x[50],sum,vsum,xbar,sigmax,sd;
    int n,i;
    printf("\nHow many values: ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
     {
        printf("\nEnter your %dth value: ",i+1);
        scanf("%f",&x[i]);
     }
    sum = 0;
    for(i=0;i<n;i++)
      sum = sum + x[i];
    xbar = sum / n;
    vsum = 0;
    for(i=0;i<n;i++)
     vsum = vsum + (x[i]-xbar) * (x[i]-xbar);
    sigmax = vsum/n;
    sd = sqrt(sigmax);
    printf("\nThe means is %3.3f",xbar);
    printf("\nThe SD Standard Deviation is %3.3f",sd);
    getch();
}